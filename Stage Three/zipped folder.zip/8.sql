SELECT channel_used,
	SUM(conversion_rate * impressions) AS totalconversions
FROM campaigndata
GROUP BY channel_used
ORDER BY totalconversions DESC;