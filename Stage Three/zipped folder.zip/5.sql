SELECT (SUM(clicks) * 100.0) / SUM(impressions) 
	AS overallctr
FROM campaigndata;