SELECT campaign_id, company, 
       (acquisition_cost/(conversion_rate * impressions)) 
	   AS costperconversion
FROM campaigndata
ORDER BY costperconversion
LIMIT 1;