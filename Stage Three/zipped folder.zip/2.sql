SELECT campaign_id, company, roi
FROM campaigndata
ORDER BY roi DESC
LIMIT 1;