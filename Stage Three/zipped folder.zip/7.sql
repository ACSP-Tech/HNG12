WITH campaigndata AS
(
SELECT campaign_id, company, 
	(SUM(clicks) * 100.0) / SUM(impressions) AS ctr
FROM public.campaigndata
GROUP BY campaign_id, company
)
SELECT *
FROM campaigndata
WHERE ctr > 5